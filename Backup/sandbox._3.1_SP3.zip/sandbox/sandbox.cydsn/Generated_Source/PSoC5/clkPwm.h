/*******************************************************************************
* File Name: clkPwm.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_clkPwm_H)
#define CY_CLOCK_clkPwm_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void clkPwm_Start(void) ;
void clkPwm_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void clkPwm_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void clkPwm_StandbyPower(uint8 state) ;
void clkPwm_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 clkPwm_GetDividerRegister(void) ;
void clkPwm_SetModeRegister(uint8 modeBitMask) ;
void clkPwm_ClearModeRegister(uint8 modeBitMask) ;
uint8 clkPwm_GetModeRegister(void) ;
void clkPwm_SetSourceRegister(uint8 clkSource) ;
uint8 clkPwm_GetSourceRegister(void) ;
#if defined(clkPwm__CFG3)
void clkPwm_SetPhaseRegister(uint8 clkPhase) ;
uint8 clkPwm_GetPhaseRegister(void) ;
#endif /* defined(clkPwm__CFG3) */

#define clkPwm_Enable()                       clkPwm_Start()
#define clkPwm_Disable()                      clkPwm_Stop()
#define clkPwm_SetDivider(clkDivider)         clkPwm_SetDividerRegister(clkDivider, 1u)
#define clkPwm_SetDividerValue(clkDivider)    clkPwm_SetDividerRegister((clkDivider) - 1u, 1u)
#define clkPwm_SetMode(clkMode)               clkPwm_SetModeRegister(clkMode)
#define clkPwm_SetSource(clkSource)           clkPwm_SetSourceRegister(clkSource)
#if defined(clkPwm__CFG3)
#define clkPwm_SetPhase(clkPhase)             clkPwm_SetPhaseRegister(clkPhase)
#define clkPwm_SetPhaseValue(clkPhase)        clkPwm_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(clkPwm__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define clkPwm_CLKEN              (* (reg8 *) clkPwm__PM_ACT_CFG)
#define clkPwm_CLKEN_PTR          ((reg8 *) clkPwm__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define clkPwm_CLKSTBY            (* (reg8 *) clkPwm__PM_STBY_CFG)
#define clkPwm_CLKSTBY_PTR        ((reg8 *) clkPwm__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define clkPwm_DIV_LSB            (* (reg8 *) clkPwm__CFG0)
#define clkPwm_DIV_LSB_PTR        ((reg8 *) clkPwm__CFG0)
#define clkPwm_DIV_PTR            ((reg16 *) clkPwm__CFG0)

/* Clock MSB divider configuration register. */
#define clkPwm_DIV_MSB            (* (reg8 *) clkPwm__CFG1)
#define clkPwm_DIV_MSB_PTR        ((reg8 *) clkPwm__CFG1)

/* Mode and source configuration register */
#define clkPwm_MOD_SRC            (* (reg8 *) clkPwm__CFG2)
#define clkPwm_MOD_SRC_PTR        ((reg8 *) clkPwm__CFG2)

#if defined(clkPwm__CFG3)
/* Analog clock phase configuration register */
#define clkPwm_PHASE              (* (reg8 *) clkPwm__CFG3)
#define clkPwm_PHASE_PTR          ((reg8 *) clkPwm__CFG3)
#endif /* defined(clkPwm__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define clkPwm_CLKEN_MASK         clkPwm__PM_ACT_MSK
#define clkPwm_CLKSTBY_MASK       clkPwm__PM_STBY_MSK

/* CFG2 field masks */
#define clkPwm_SRC_SEL_MSK        clkPwm__CFG2_SRC_SEL_MASK
#define clkPwm_MODE_MASK          (~(clkPwm_SRC_SEL_MSK))

#if defined(clkPwm__CFG3)
/* CFG3 phase mask */
#define clkPwm_PHASE_MASK         clkPwm__CFG3_PHASE_DLY_MASK
#endif /* defined(clkPwm__CFG3) */

#endif /* CY_CLOCK_clkPwm_H */


/* [] END OF FILE */
