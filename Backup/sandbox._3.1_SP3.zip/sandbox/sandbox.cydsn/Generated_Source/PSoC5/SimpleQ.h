/* ======================================================================== */
/*
 * Copyright (c) 2015, E2ForLife.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the E2ForLife.com nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL E2FORLIFE.COM BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* ======================================================================== */
#if !defined(SimpleQ_H)
	#define SimpleQ_H
	
#include <cytypes.h>
	
void SimpleQ_Flush( uint8 *q );
cystatus SimpleQ_Create( uint8 *q, uint16 array_size );
cystatus SimpleQ_Read(uint8* value, uint8* q);
cystatus SimpleQ_Write(uint8 value, uint8* q);
int SimpleQ_DataReady( uint8* q );
uint8 SimpleQ_Peek(uint8* q);


#define SimpleQ_ARRAY_SIZE(s)                ( s + 8 )

/*
 * Fifo Format:
 * byte 1:0  -  Fifo Length
 * byte 3:2  -  Maximum data length
 * byte 5:4  -  FIFO Read Ptr
 * byte 7:6  -  FIFO Write Ptr
 * Byte 8... -  FIFO Data
 */
#define SimpleQ_IDX_ReadPtr              ( 4 )
#define SimpleQ_IDX_WritePtr             ( 6 )
#define SimpleQ_IDX_Size                 ( 2 )
#define SimpleQ_IDX_Max                  ( 0 )
#define SimpleQ_IDX_QStart               ( 8 )

#define SimpleQ_QReadPtr(q)              ( *((uint16*)&q[SimpleQ_IDX_ReadPtr]) )
#define SimpleQ_QWritePtr(q)             ( *((uint16*)&q[SimpleQ_IDX_WritePtr]) )
#define SimpleQ_QSize(q)                 ( *((uint16*)&q[SimpleQ_IDX_Size]) )
#define SimpleQ_QMax(q)                  ( *((uint16*)&q[SimpleQ_IDX_Max]) )
#define SimpleQ_QData(q,i)               ( *((uint8*)&q[SimpleQ_IDX_QStart+i]) )


/*
 * MACRO used to insert value (v) in to initialized fifo (f).  this does
 * 0 error checking and when the FIFO is full does not insert data to prevent
 * overflow, so there should be enough room in the fifo to allow for inserting
 * all of the expected bytes to prevent loss. mainly, use this for ISR handling
 * and use the interface functions for FIFO operations when not in ISR context.
 */
#define SimpleQ_INLINE_QWrite(v,q) \
		if (SimpleQ_QSize(q) < SimpleQ_QMax(q)) { \
    		SimpleQ_QData(q, SimpleQ_QWritePtr(q)) = v;\
			SimpleQ_QWritePtr(q) = SimpleQ_QWritePtr(q) + 1;\
			if (SimpleQ_QWritePtr(q) >= SimpleQ_QMax(q)) {\
				SimpleQ_QWritePtr(q) = 0;\
			}\
			SimpleQ_QSize(q) = SimpleQ_QSize(q) + 1;\
		}
		
		
#endif
/* [] END OF FILE */
