/* ======================================================================== */
/*
 * Copyright (c) 2015, E2ForLife.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the E2ForLife.com nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL E2FORLIFE.COM BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* ======================================================================== */
#include <cytypes.h>
#include <cylib.h>
#include <stdio.h>

#include "COMIO.h"
#include "USBUART.h"

#if (COMIO_USB_MODE == COMIO_YES)
#include "USBUART_cdc.h"
#endif

/* ======================================================================== */
#define COMIO_QMAX_IDX      ( 2 )
#define COMIO_QSIZE_IDX     ( 0 )
#define COMIO_QREAD_IDX     ( 4 )
#define COMIO_QWRITE_IDX    ( 6 )
#define COMIO_QBASE_IDX     ( 8 )

#define COMIO_QReadPtr(q)   ( *((uint16*)&q[ COMIO_QREAD_IDX ]) )
#define COMIO_QWritePtr(q)  ( *((uint16*)&q[ COMIO_QWRITE_IDX ]) )
#define COMIO_QSize(q)      ( *((uint16*)&q[ COMIO_QSIZE_IDX ]))
#define COMIO_QMax(q)       ( *((uint16*)&q[ COMIO_QMAX_IDX]))
#define COMIO_QData(q,i)    ( *((uint8*)&q[ i + COMIO_QBASE_IDX]))

/* Local Receive FIFO */
uint8 COMIO_RxQ[ COMIO_RX_SIZE + 8];

/* Local Transmit FIFO */
uint8 COMIO_TxQ[ COMIO_TX_SIZE + 8 ];

uint8 COMIO_initVar;

/* ======================================================================== */
void COMIO_Start( void )
{
	if (COMIO_initVar != 1) {
		COMIO_Init();
	}
	
	/* Check for enumeration after initialization */
	COMIO_Enable();
}
/* ------------------------------------------------------------------------ */
void COMIO_Init( void )
{
	/* Initialize USB Buffers */
	memset((void*)COMIO_RxQ, 0, COMIO_RX_SIZE + 8);
	memset((void*)COMIO_TxQ, 0, COMIO_TX_SIZE + 8);
	COMIO_QMax(COMIO_RxQ) = COMIO_RX_SIZE;
	COMIO_QMax(COMIO_TxQ) = COMIO_TX_SIZE;
	
	
    /* Enable Global Interrupts */
    CyGlobalIntEnable;                        

	if (USBUART_initVar == 0) {
    	/* Start USBFS Operation with 3V operation */
		#if (CYDEV_VDDIO1_MV < 5000)
    		USBUART_Start(0u, USBUART_3V_OPERATION);
		#else
			USBUART_Start(0u, USBUART_5V_OPERATION);
		#endif
	}
	
	#if ( ( == 1)&&( == 1) )
		
	#endif
	
	COMIO_initVar = 1;
}	
/* ======================================================================== */
void COMIO_QWrite(uint8* q, uint8 value)
{
	/*
	 * first check for overflow on received data and adjust the Q so that
	 * there is room for the new byte.
	 */
	if (COMIO_QSize(q) >= COMIO_QMax(q) ) {
		COMIO_QSize(q) = COMIO_QSize(q) - 1;
		COMIO_QReadPtr(q) = COMIO_QReadPtr(q) + 1;
		if (COMIO_QReadPtr(q) >= COMIO_QMax(q) ) {
			COMIO_QReadPtr(q) = 0;
		}
	}
	
	COMIO_QData(q,COMIO_QWritePtr(q)) = value;
	COMIO_QWritePtr(q) = COMIO_QWritePtr(q) + 1;
	if (COMIO_QWritePtr(q) >= COMIO_QMax(q) ) {
		COMIO_QWritePtr(q) = 0;
	}	
}
/* ------------------------------------------------------------------------ */
uint8 COMIO_QRead(uint8* q)
{
	uint8 value;
	
	value = 0xFF;
	if (COMIO_QSize(q) > 0) {
		value = COMIO_QData(q, COMIO_QReadPtr(q));
		COMIO_QReadPtr(q) = COMIO_QReadPtr(q) + 1;
		if (COMIO_QReadPtr(q) >= COMIO_QMax(q) ) {
			COMIO_QReadPtr(q) = 0;
		}
		COMIO_QSize(q) = COMIO_QSize(q) - 1;
	}
	return value;
}
/* ------------------------------------------------------------------------ */
uint8 COMIO_QPeek( uint8* q )
{
	uint8 value;
	
	if (COMIO_QSize(q) > 0) {
		value = COMIO_QData(q,COMIO_QReadPtr(q));
	}
	else {
		value = 0;
	}
	return value;
}
/* ======================================================================== */
void COMIO_Idle( void )
{
    uint16 count;
    uint8 buffer[COMIO_BUFFER_LEN];
	uint16 idx;
	
	/* Handle enumeration of USB port */
    if(USBUART_IsConfigurationChanged() != 0u) /* Host could send double SET_INTERFACE request */
    {
        if(USBUART_GetConfiguration() != 0u)   /* Init IN endpoints when device configured */
        {
            /* Enumeration is done, enable OUT endpoint for receive data from Host */
            USBUART_CDC_Init();
        }
    }
	/* Service the USB CDC */
    if(USBUART_GetConfiguration() != 0u)
    {
        if(USBUART_DataIsReady() != 0u)               /* Check for input data from PC */
        {   
            count = USBUART_GetAll(buffer);           /* Read received data and re-enable OUT endpoint */
            if(count != 0u)
            {
				/* insert data in to Receive FIFO */
				for(idx=0;idx<count;++idx) {
					COMIO_QWrite(COMIO_RxQ, buffer[idx]);
				}
			}
		}
		/*
		 * detrmine if there is data to be sent from the buffer to the host,
		 * and send a block of data from the FIFO up to the endpoint limit.
		 */
		if (COMIO_QSize(COMIO_TxQ ) > 0) {
#if (COMIO_BLOCKING_SEND == COMIO_YES)
			/* Wait till component is ready to send more data to the PC */			
            while(USBUART_CDCIsReady() == 0u);
#else
			if (USBUART_CDCIsReady() == 0) return;
#endif
			count = 0;
			while ( (count < COMIO_BUFFER_LEN) && (COMIO_QSize(COMIO_TxQ) > 0) ) {
				buffer[count++] = COMIO_QRead(COMIO_TxQ);
			}
			/* Send data back to host */
            USBUART_PutData(buffer, count);
            /* If the last sent packet is exactly maximum packet size, 
             *  it shall be followed by a zero-length packet to assure the
             *  end of segment is properly identified by the terminal.
             */
            if(count == COMIO_BUFFER_LEN){
				/* Wait till component is ready to send more data to the PC */
                while(USBUART_CDCIsReady() == 0u); 
                USBUART_PutData(NULL, 0u);         /* Send zero-length packet to PC */
            }
        }  
	}
}
/* ------------------------------------------------------------------------ */
char COMIO_GetChar( void )
{
	char value;
	
	/* wait for data to become available */
	COMIO_Idle();
	while (COMIO_QSize(COMIO_RxQ) == 0) {
		COMIO_Idle();
	}
	
	value = (char) COMIO_QRead(COMIO_RxQ);
	
	return value;
}
/* ------------------------------------------------------------------------ */
cystatus COMIO_PutChar( char ch )
{
	cystatus result;
	
	/* set default, and process USB CDC port */
	result = CYRET_SUCCESS;
	COMIO_Idle();
	/* insert character in to the send fifo */
	COMIO_QWrite(COMIO_TxQ, ch);
	/*
	 * The transmot data has been placed in to the Tx buffer, so no, try to
	 * send some (or all) of it.
	 */
	COMIO_Idle();
	
	return result;
}
/* ------------------------------------------------------------------------ */
cystatus COMIO_PrintString( const char *str )
{
	int idx;
	cystatus result;
	
	COMIO_Idle();

	result = CYRET_SUCCESS;
	idx = 0;
	while ( (str[idx] != 0) && (result == CYRET_SUCCESS) ) {
		/* insert character in to the send fifo */
		COMIO_QWrite(COMIO_TxQ,str[idx++]);		
	}
	/*
	 * The transmot data has been placed in to the Tx buffer, so no, try to
	 * send some (or all) of it.
	 */
	COMIO_Idle();
	return result;
}
/* ------------------------------------------------------------------------ */
cystatus COMIO_SetColor( uint8 fg, uint8 bg )
{
	char buffer[21];
	
	fg = (fg > 7) ?	(90 + (fg&0x07)):(fg + 30);
	bg = (bg > 7) ? (100+(bg&7)):(bg + 40);
	sprintf(buffer,"\x1b[%d;%dm",fg,bg);
	return COMIO_PrintString(buffer);
}
/* ------------------------------------------------------------------------- */
cystatus COMIO_ClearLine(uint8 mode)
{
	char buffer[15];
	
	sprintf(buffer,"\x1b[%dK",mode);
	return COMIO_PrintString(buffer);
}
/* ------------------------------------------------------------------------- */
cystatus COMIO_Position(uint8 row, uint8 col)
{
	char buffer[21];
	
	sprintf(buffer,"\x1b[%d;%dH",row+1,col+1);
	return COMIO_PrintString(buffer);
}
/* ------------------------------------------------------------------------- */
cystatus COMIO_PrintStringColor(const char *str, uint8 fg, uint8 bg)
{
	cystatus result;
	int idx;
	
	result = COMIO_SetColor(fg,bg);
	idx = 0;
	while ( (str[idx] != 0) && (result == CYRET_SUCCESS) ) {
		if ( ( (str[idx] == '[') || (str[idx] == ']') || (str[idx] == '(') || (str[idx] == ')') ) && (bg!=4) ) {
			result = COMIO_SetColor(4,bg);
			COMIO_QWrite( COMIO_TxQ, str[idx] );
			result = COMIO_SetColor(fg,bg);
		}
		else {
			COMIO_QWrite( COMIO_TxQ, str[idx] );
		}
		++idx;
	}
	COMIO_SetColor(7,0);
	
	return result;
}
/* ------------------------------------------------------------------------- */
cystatus COMIO_GetString(char *str)
{
	cystatus result;
	char ch;
	char lookahead;
	int idx;
	
	/* Process queue'd I/O over the USB port */
	COMIO_Idle();
	
	result = CYRET_STARTED;
	idx = strlen( str );
	lookahead = (char) COMIO_QPeek(COMIO_RxQ);
	
	while (
#if (COMIO_BLOCKING_GETS == COMIO_NO)
			(COMIO_QSize(COMIO_RxQ) > 0) && 
#endif
			(lookahead != '\r') && (lookahead != '\n') ) {
		ch = COMIO_GetChar();
		lookahead = (char)COMIO_QPeek(COMIO_RxQ);
		if ( (ch == '\b') || (ch == 127) ) {
			str[idx] = 0;
			if (idx>0) {
				idx--;
			}
		}
		else {
			str[idx++] = ch;
		}
		str[idx] = 0;
	}
	
	if ( (lookahead == '\r') || (lookahead == '\n') ) {
		do {
			COMIO_GetChar(); /* Remove the EOL character from buffer */
			lookahead = COMIO_QPeek(COMIO_RxQ);
		}
		while( (lookahead == '\r') || (lookahead == '\n') );
		result = CYRET_FINISHED;
	}
	return result;
}
/* ------------------------------------------------------------------------- */
void COMIO_ClearFifo( void )
{
	COMIO_ClearTxBuffer();
	COMIO_ClearRxBuffer();
}
/* ------------------------------------------------------------------------- */
void COMIO_ClearTxBuffer( void )
{
	memset((void*)COMIO_TxQ,0, 8);
	COMIO_QMax(COMIO_TxQ) = COMIO_TX_SIZE;
}
/* ------------------------------------------------------------------------- */
void COMIO_ClearRxBuffer( void )
{
	memset((void*)COMIO_RxQ,0, 8);
	COMIO_QMax(COMIO_RxQ) = COMIO_RX_SIZE;
}
/* ------------------------------------------------------------------------- */
/*
 * scan key, and process escape sequences for command keys.
 */
uint16 COMIO_ScanKey( void )
{
	uint16 result;
	char ch;
	
	COMIO_Idle();
	result = 0;
	if (COMIO_QSize(COMIO_RxQ) > 0) {
		ch = COMIO_GetChar();
		if (ch == '\x1b') {
			ch = COMIO_GetChar(); /* wait for bracket */
			if (ch == '[') {
				do {
					ch = COMIO_GetChar(); /* Get command */
				}
				while ( !isalpha((int)ch) );
				result = (uint16) ch;
				result |= COMIO_KEY_CTRL;
			}
		}
		else {
			result = ch;
		}
	}
	return result;
}
/* ------------------------------------------------------------------------- */
/* [] END OF FILE */
