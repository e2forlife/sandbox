/* ======================================================================== */
/*
 * Copyright (c) 2015, E2ForLife.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the E2ForLife.com nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL E2FORLIFE.COM BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* ======================================================================== */
#if !defined (COMIO_H)
	#define COMIO_H

#include <cytypes.h>
	
#define COMIO_YES            ( 1 )
#define COMIO_NO             ( 0 )

#define COMIO_BLOCKING_SEND   ( 0 )
#define COMIO_BLOCKING_GETS   ( COMIO_NO )
#define COMIO_USB_MODE        ( 1 )
	
void COMIO_Start( void );
#define COMIO_Enable           COMIO_Idle
void COMIO_Init( void );

void COMIO_Idle( void );
char COMIO_GetChar( void );
cystatus COMIO_PutChar( char ch );
cystatus COMIO_PrintString( const char *str );
cystatus COMIO_SetColor( uint8 fg, uint8 bg );
cystatus COMIO_ClearLine(uint8 mode);
cystatus COMIO_Position(uint8 row, uint8 col);
cystatus COMIO_PrintStringColor(const char *str, uint8 fg, uint8 bg);
cystatus COMIO_GetString( char *str );
void COMIO_ClearFifo( void );
void COMIO_ClearTxBuffer( void );
void COMIO_ClearRxBuffer( void );
uint16 COMIO_ScanKey( void );

#define COMIO_HideCursor        ( COMIO_PutString("\x1b[?25l") )
#define COMIO_ShowCursor        ( COMIO_PutString("\x1b[?25h") )
#define COMIO_SaveCursor        ( COMIO_PutString("\x1b[s") )
#define COMIO_RestoreCursor     ( COMIO_PutString("\x1b[u") )

/* The size of the buffer is equal to maximum packet size of the 
*  IN and OUT bulk endpoints. 
*/
#define COMIO_BUFFER_LEN   ( 64u )
#define COMIO_RX_SIZE      ( 512 )
#define COMIO_TX_SIZE      ( 512 )

/* ------------------------------------------------------------------------ */
#define COMIO_KEY_UP         ( 'A' )
#define COMIO_KEY_DOWN       ( 'B' )
#define COMIO_KEY_LEFT       ( 'D' )
#define COMIO_KEY_RIGHT      ( 'C' )

#define COMIO_KEY_CTRL       ( 0x8000 )
/* ------------------------------------------------------------------------ */

#if (1 == 1)
	
/*
 * read function/write function pointer types
 * These types are used to fill in the symbol table, which ultimately defines
 * the symbol table commands for execution.  defining a funtion as NULL will
 * disallow the mode of operation, writes will flag an error, but reads are
 * quiet.  The value is passed as a token type for reads (not an actual value)
 * so that the writer can handle the parsing of the value string for typing.
 * i.e. POWER wants on or off.
 */
typedef cystatus (*COMIO_CLIfunc)( int, char** );

typedef struct {
	char name[15];   /* Command name */
	COMIO_CLIfunc fn;     /* Parser callback to be executed */
	char desc[71];   /* ASCII description of function (for helper) */
} COMIO_CLI_COMMAND;
	
#define CMD_NOTE       ( 0 )
#define CMD_WARN       ( 1 )
#define CMD_ERROR      ( 2 )
#define CMD_FATAL      ( 0xFF )

 void COMIO_CliIdle( const COMIO_CLI_COMMAND *tbl, uint8 refresh );
	
#endif

#endif
/* [] END OF FILE */
